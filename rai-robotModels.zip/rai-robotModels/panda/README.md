# Franka Emika Panda

![pic of Panda](https://github.com/MarcToussaint/rai-robotModels/raw/master/panda/panda.png)

Converted from

[[https://github.com/frankaemika/franka_ros/tree/kinetic-devel/franka_description]]
